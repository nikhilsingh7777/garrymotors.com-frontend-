import React from 'react'
import styles from "@/styles/About.module.css";


const about = () => {
  return (
    <div className={styles.container}>
      <img src="abouthead.png" alt="" className={styles.imgi} />
      <img src="about.png" alt="" className={styles.img}/>
      <img src="abouts.png" alt="" className={styles.imgs}/>
    </div>
  )
}

export default about