import CarCard from '@/components/CarCard/CarCard'
import React, { useState, useEffect } from 'react'
import styles from "@/styles/Cars.module.css"
import newRequest from '@/utils/newRequest'
import Search from '@/components/Search/Search'

const cars = () => {
  const [cars, setCars] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchCars = async () => {
      try {
        const response = await newRequest.get('/car');
        setCars(response.data);
      } catch (error) {
        console.error('Error fetching cars:', error);
      }
    };

    fetchCars();
  }, []);

  const handleSearch = (query) => {
    setSearchQuery(query.toLowerCase());
  };

  const filteredCars = cars.filter(car => 
    car.car.toLowerCase().includes(searchQuery)
  );

  return (
    <div className={styles.container}>
      <img src="garage.png" alt="" className={styles.carimg} />
      <img src="garages.png" alt="" className={styles.carimgs} />
      <Search onSearch={handleSearch}/>
      {filteredCars.length > 0 ? (
        filteredCars.map(car => <CarCard key={car._id} car={car} />)
      ) : (
        <h2>Awesome Cars are on the way! Check back later.</h2>
      )}
    </div>
  )
}

export default cars